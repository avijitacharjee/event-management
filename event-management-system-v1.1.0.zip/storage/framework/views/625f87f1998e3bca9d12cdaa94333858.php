<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginaldcefe0de24519922a91bc39bd814f585 = $component; } ?>
<?php $component = App\View\Components\Modals\OrgSettingsModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modals.org-settings-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modals\OrgSettingsModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldcefe0de24519922a91bc39bd814f585)): ?>
<?php $component = $__componentOriginaldcefe0de24519922a91bc39bd814f585; ?>
<?php unset($__componentOriginaldcefe0de24519922a91bc39bd814f585); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal42abee4723a1023a2fca81c7a8be3330 = $component; } ?>
<?php $component = App\View\Components\Modals\OrgPrivacySettingsModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modals.org-privacy-settings-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modals\OrgPrivacySettingsModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42abee4723a1023a2fca81c7a8be3330)): ?>
<?php $component = $__componentOriginal42abee4723a1023a2fca81c7a8be3330; ?>
<?php unset($__componentOriginal42abee4723a1023a2fca81c7a8be3330); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal4a94681917372885745609d3ce32f7ba = $component; } ?>
<?php $component = App\View\Components\Modals\OrgProfileUpdateModal::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modals.org-profile-update-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Modals\OrgProfileUpdateModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a94681917372885745609d3ce32f7ba)): ?>
<?php $component = $__componentOriginal4a94681917372885745609d3ce32f7ba; ?>
<?php unset($__componentOriginal4a94681917372885745609d3ce32f7ba); ?>
<?php endif; ?>
    <div class="wrapper wrapper-body">
        <div class="dashboard-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="d-main-title">
                            <h3>
                                <i class="fa-solid fa-circle-info me-3"></i>About My Organisation
                            </h3>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="conversion-setup">
                            <div class="main-card mt-5">
                                <div class="bp-title position-relative">
                                    <h4>About</h4>
                                    <div class="profile-edit-btn">
                                        <a href="<?php echo e(url('#')); ?>" data-bs-toggle="modal" data-bs-target="#orgSettings"
                                            class="btn"><i class="fa-solid fa-user-gear"></i></a>
                                        <a href="<?php echo e(url('#')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#orgPrivacySettings" class="btn"><i
                                                class="fa-solid fa-gear"></i></a>
                                        <a href="<?php echo e(url('#')); ?>" data-bs-toggle="modal"
                                            data-bs-target="#org-profile-update-pop" class="btn"><i
                                                class="fa-solid fa-pen"></i></a>
                                    </div>
                                </div>
                                <div class="about-details">
                                    <div class="about-step text-center">
                                        <div class="user-avatar-img">
                                            <img src="<?php echo e(asset('/asset/barren/images/avatar.svg')); ?>"
                                                alt="" />
                                        </div>
                                        <div class="user-dts">
                                            <h4 class="user-name">
                                                <?php echo e(auth()->user()->name); ?><span class="verify-badge"><i
                                                        class="fa-solid fa-circle-check"></i></span>
                                            </h4>
                                            <span class="user-email">
                                                <?php echo e(auth()->user()->email); ?>

                                            </span>
                                        </div>
                                    </div>
                                    <div class="about-step">
                                        <h5>
                                            Tell us about yourself and let
                                            people know who you are
                                        </h5>
                                        <p class="mb-0">
                                            Lorem ipsum dolor sit amet,
                                            consectetur adipiscing elit. Ut
                                            tincidunt interdum nunc et
                                            auctor. Phasellus quis pharetra
                                            sapien. Integer ligula sem,
                                            sodales vitae varius in, varius
                                            eget augue.
                                        </p>
                                    </div>
                                    <div class="about-step">
                                        <h5>Find me on</h5>
                                        <div class="social-links">
                                            <a href="<?php echo e(url('#')); ?>" class="social-link" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="" data-bs-original-title="Facebook"
                                                aria-label="Facebook"><i class="fab fa-facebook-square"></i></a>
                                            <a href="<?php echo e(url('#')); ?>" class="social-link" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="" data-bs-original-title="Instagram"
                                                aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                                            <a href="<?php echo e(url('#')); ?>" class="social-link" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="" data-bs-original-title="Twitter"
                                                aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                                            <a href="<?php echo e(url('#')); ?>" class="social-link" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="" data-bs-original-title="LinkedIn"
                                                aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                                            <a href="<?php echo e(url('#')); ?>" class="social-link" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="" data-bs-original-title="Youtube"
                                                aria-label="Youtube"><i class="fab fa-youtube"></i></a>
                                            <a href="<?php echo e(url('#')); ?>" class="social-link" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="" data-bs-original-title="Website"
                                                aria-label="Website"><i class="fa-solid fa-globe"></i></a>
                                        </div>
                                    </div>
                                    <div class="about-step">
                                        <h5>Address</h5>
                                        <p class="mb-0">
                                            // TODO addre
                                        </p>
                                    </div>
                                    <div class="about-step">
                                        <a href="<?php echo e(url('#')); ?>" class="view-profile-link a-link">View Public
                                            Profile<i class="fa-solid fa-arrow-up-right-from-square ms-2"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('organization.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\event-management-system\resources\views/organization/profile.blade.php ENDPATH**/ ?>