<nav class="vertical_nav">
    <div class="left_section menu_left" id="js-menu">
        <div class="left_section">
            <ul>
                <li class="menu--item">
                    <a href="<?php echo e(url('organization/dashboard')); ?>"
                        class="menu--link <?php echo e(request()->is('organization/dashboard') ? 'active' : ''); ?>" title="Dashboard"
                        data-bs-toggle="tooltip" data-bs-placement="right">
                        <i class="fa-solid fa-gauge menu--icon"></i>
                        <span class="menu--label">Dashboard</span>
                    </a>
                </li>
                <li class="menu--item">
                    <a href="<?php echo e(url('organization/events')); ?>"
                        class="menu--link <?php echo e(request()->is('organization/events') ? 'active' : ''); ?>" title="Events"
                        data-bs-toggle="tooltip" data-bs-placement="right">
                        <i class="fa-solid fa-calendar-days menu--icon"></i>
                        <span class="menu--label">Events</span>
                    </a>
                </li>
                
                <li class="menu--item">
                    <a href="<?php echo e(url('/organization/payouts')); ?>"
                        class="menu--link <?php echo e(request()->is('organization/payouts') ? 'active' : ''); ?>" title="Payouts"
                        data-bs-toggle="tooltip" data-bs-placement="right">
                        <i class="fa-solid fa-credit-card menu--icon"></i>
                        <span class="menu--label">Payouts</span>
                    </a>
                </li>
                
                
                <li class="menu--item">
                    <ul>
                        <li class="menu--item__has_sub_menu">
                            <a
                                class="menu--link <?php echo e(request()->is('organization/blogs') ? 'active' : ''); ?>"
                                title="Blogs" data-bs-toggle="tooltip" data-bs-placement="right">
                                <i class="fa-solid fa-circle-info menu--icon"></i>
                                <span class="menu--label">Blogs</span>
                            </a>
                        </li>
                        <li class="sub_menu">
                            <a href="<?php echo e(url('/organization/blogs')); ?>" class="sub_menu--link" title="About"
                                data-bs-toggle="tooltip" data-bs-placement="right">
                                <i class="fa-solid fa-circle-info menu--icon"></i>
                                <span class="menu--label">See Blogs</span>
                            </a>
                        </li>
                        
                    </ul>
                </li>
                <li class="menu--item">
                    <a href="<?php echo e(url('/organization/profile')); ?>" class="menu--link <?php echo e(request()->is('organization/profile')?'active':''); ?>"
                        title="About" data-bs-toggle="tooltip" data-bs-placement="right">
                        <i class="fa-solid fa-circle-info menu--icon"></i>
                        <span class="menu--label">Profile</span>
                    </a>
                </li>

                </li>
                
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH I:\Projects\Laravel\event-management-system\resources\views/organization/sidebar.blade.php ENDPATH**/ ?>