<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="breadcrumb-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-10">
                        <div class="barren-breadcrumb">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo e(url('/')); ?>">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Our Blog
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="event-dt-block p-80">
            <div class="most-popular-posts">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="slide-posts">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12">
                                        <div class="">
                                            <div class="owl-carousel most-posts-slider owl-theme">
                                                <?php $__currentLoopData = $topBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="item">
                                                        <div class="main-card">
                                                            <div class="blog-block flex-slide">
                                                                <div class="blog-img-card left">
                                                                    <a href="<?php echo e(url('/blog/3')); ?>" class="bbig-img">
                                                                        <img src="<?php echo e(asset($blog->image)); ?>"
                                                                            alt="" />
                                                                    </a>
                                                                </div>
                                                                <div class="blog-content right">
                                                                    <a href="<?php echo e(url('blog/' . $blog->id)); ?>"
                                                                        class="blog--title"><?php echo e($blog->title); ?></a>
                                                                    <p class="mb-4">
                                                                        <?php echo str($blog->content)->limit(100); ?>

                                                                    </p>
                                                                    <div class="post-meta">
                                                                        <span class="post-date me-4"><i
                                                                                class="fa-regular fa-calendar-days me-2"></i><?php echo e($blog->created_at->format('j F, Y')); ?></span>
                                                                        
                                                                    </div>
                                                                    <a href="<?php echo e(url('blog/' . $blog->id)); ?>"
                                                                        class="main-btn h_50 btn-hover bt_40">View
                                                                        Post</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="latest-posts Bp-top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="main-title checkout-title">
                                <h3>Latest Posts</h3>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <div class="bt_40">
                                <div class="row g-4">
                                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="main-card">
                                                <div class="blog-thumbnail">
                                                    <a href="<?php echo e(url('blog/'.$blog->id)); ?>" class="thumbnail-img">
                                                        <img src="<?php echo e(asset($blog->image)); ?>"
                                                            alt="" />
                                                    </a>
                                                </div>
                                                <div class="blog-content">
                                                    <a href="<?php echo e(url('blog/'.$blog->id)); ?>" class="blog-title fs-16"><?php echo e($blog->title); ?></a>
                                                    <div class="post-meta bt_33">
                                                        <span class="post-date fs-14"><i
                                                                class="fa-regular fa-calendar-days me-2"></i>
                                                            <?php echo e($blog->created_at->format('j F, Y')); ?>

                                                            </span>
                                                        
                                                        <span class="post-read-time fs-14">
                                                            <i class="fa fa-eye"></i>
                                                            <?php echo e($blog->view_count); ?>

                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Projects\Laravel\event-management-system\resources\views/blog/blogs.blade.php ENDPATH**/ ?>